export interface DataPoint {
  date: string
  actual: number | null
  forecast: number | null
}
